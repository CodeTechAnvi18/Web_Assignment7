const apiKey = '5da75fa6113941320e4584285fc35616'; // Replace with your OpenWeatherMap API key

    document.getElementById('get-weather').addEventListener('click', () => {
      const city = document.getElementById('city-input').value;
      const units = document.getElementById('unit-select').value;
      const endpoint = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=${units}&appid=${apiKey}`;

      fetch(endpoint)
        .then(response => {
          if (!response.ok) {
            throw new Error('City not found');
          }
          return response.json();
        })
        .then(data => {
          const temp = data.main.temp;
          const condition = data.weather[0].description;
          const icon = `https://openweathermap.org/img/wn/${data.weather[0].icon}.png`;

          document.getElementById('weather-output').innerHTML = `
            <h2>${data.name}</h2>
            <p>Temperature: ${temp}°</p>
            <p>Condition: ${condition}</p>
            <img class="weather-icon" src="${icon}" alt="weather icon">
          `;
          document.getElementById('error-message').innerText = '';
        })
        .catch(error => {
          document.getElementById('error-message').innerText = error.message;
        });
    });

  